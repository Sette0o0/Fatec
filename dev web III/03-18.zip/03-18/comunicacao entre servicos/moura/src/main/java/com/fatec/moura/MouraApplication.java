package com.fatec.moura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MouraApplication {

	public static void main(String[] args) {
		SpringApplication.run(MouraApplication.class, args);
	}

}
