package com.fatec.caderneta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadernetaApplicationTests {

	@Test
	void contextLoads() {
	}

}
